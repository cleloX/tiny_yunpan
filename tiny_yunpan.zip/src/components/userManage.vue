<template>
  <div class="userManage">
    <el-container>
      <el-header>Header</el-header>
      <el-main>
        <el-row>
          <el-col :span="4"><div class="active grid-content bg-purple">用户名</div></el-col>
          <el-col :span="4"><div class="active grid-content bg-purple">手机号</div></el-col>
          <el-col :span="4"><div class="active grid-content bg-purple">邮箱</div></el-col>
          <el-col :span="4"><div class="active grid-content bg-purple">真实姓名</div></el-col>
          <el-col :span="4"><div class="active grid-content bg-purple">用户操作</div></el-col>
          <el-col :span="4"><div class="active grid-content bg-purple">用户请求</div></el-col>
        </el-row>
        <el-row v-for="(item,index) in userList">
          <el-col :span="4"><div class="grid-content bg-purple">{{item.username}}</div></el-col>
          <el-col :span="4"><div class="grid-content bg-purple">{{item.phone}}</div></el-col>
          <el-col :span="4"><div class="grid-content bg-purple">{{item.email}}</div></el-col>
          <el-col :span="4"><div class="grid-content bg-purple">{{item.name}}</div></el-col>
          <el-col :span="4"><div class="grid-content bg-purple">
            <i class="el-icon-warning-outline" v-if="item.status" @click="statusToFalse(item.username,index)"></i>
            <i class="el-icon-warning" v-if="!item.status" @click="statusToTrue(item.username,index)"></i>
            <i class="el-icon-delete" @click="userDel(item.username,index)"></i>
          </div></el-col>
          <el-col :span="4"><div class="grid-content bg-purple">
            <i class="el-icon-circle-check"></i>
            <i class="el-icon-circle-close"></i>
          </div></el-col>
        </el-row>
      </el-main>
    </el-container>
  </div>
</template>

<script>
  export default {
    name: "userManage",
    data(){
      return{
        requestChange:null,
        userList:[
          {
            username:'11',
            phone:'123123',
            email:'123123',
            name:'11',
            status:true
          },
          {
            username:'22',
            phone:'2222',
            email:'2222',
            name:'22222',
            status:true
          },
          {
            username:'33',
            phone:'333',
            email:'333333',
            name:'3333333',
            status:false
          }
        ]
      }
    },
    methods:{
      statusToFalse(username,index){
        this.userList[index].status = false
      },
      statusToTrue(username,index){
        this.userList[index].status = true
      },
      userDel(username,index){
        this.userList.splice(index,1)
      }
    }
  }
</script>

<style scoped>
   .userManage{
     height: 100vh;
     /*background-color: #3B2835;*/
   }
  .el-header {
    background-color: rgba(46, 108, 205, 0.31);
    color: #333;
    text-align: center;
    line-height: 3rem;
  }

  .el-main {
    background-color: #E9EEF3;
    color: #333;
    text-align: center;
    /*line-height: 500px;*/
    height: 95vh;
  }

   .el-row .el-col:nth-child(6){
     margin-bottom: 0.1rem;
   }

   .el-col {
     border-radius: 4px;
     line-height: 36px;
     align-items: center;
     align-content: center;
   }
   .bg-purple {
     background: rgba(211, 220, 230, 0.36);
   }
   .grid-content {
     border-radius: 4px;
     min-height: 36px;
   }
  .active{
    background: rgb(211, 220, 230);
  }
  .el-icon-circle-check{
    color: green;
    margin-right: 1.5rem;
    font-size: 1.5rem;
  }
  .el-icon-circle-close{
    color: red;
    font-size: 1.5rem;
  }
  .el-icon-warning-outline{
    color: green;
    margin-right: 1.5rem;
    font-size: 1.5rem;
  }
  .el-icon-warning{
    color: red;
    margin-right: 1.5rem;
    font-size: 1.5rem;
  }
  .el-icon-delete{
    color: red;
    font-size: 1.5rem;
  }
</style>
